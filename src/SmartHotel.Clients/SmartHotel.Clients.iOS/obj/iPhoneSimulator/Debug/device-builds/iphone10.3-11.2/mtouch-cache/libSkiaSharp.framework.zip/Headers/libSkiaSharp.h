//
//  libSkiaSharp.h
//  libSkiaSharp
//
//  Created by Bill Holmes on 11/21/15.
//  Copyright © 2015 Xamarin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for libSkiaSharp.
FOUNDATION_EXPORT double libSkiaSharpVersionNumber;

//! Project version string for libSkiaSharp.
FOUNDATION_EXPORT const unsigned char libSkiaSharpVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libSkiaSharp/PublicHeader.h>


